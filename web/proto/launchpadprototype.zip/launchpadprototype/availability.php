<?php

include('functions.php');

print availabilityCountersDisplay();
